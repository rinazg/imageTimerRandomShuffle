﻿using System;
using System.Windows.Forms;

namespace ImageTimer
{
    public partial class Form1 : Form
    {
        string[] pArr = { "mother.jpeg", "rabbit.gif", "sun.jpg"};
        string[] pArrDesc = { "אמא", "ארנב", "שמש" };
        string[] randAns = { "אמא", "ארנב", "שמש" };
        int interval; //timer interval value;
        int index; //index of random picture used in several method 

        public Form1()
        {
            InitializeComponent();
            chooseImage();
            interval = 5000;
            timer1.Start(); //starts timer
        }

        //choosing a random image from image
        private void chooseImage()
        {
            Random rnd = new Random();
            index = rnd.Next(0, pArr.Length);
            pictureBox1.ImageLocation = @"..\..\pics\" + pArr[index];
        }

        void reshuffle(string[] Arr)
        {
            Random rnd = new Random();
            string tmp;
            int r;
            // Knuth shuffle algorithm :: courtesy of Wikipedia :)
            for (int t = 0; t < Arr.Length; t++)
            {
                tmp = Arr[t];
                r = rnd.Next(t,Arr.Length);
                Arr[t] = Arr[r];
                Arr[r] = tmp;
            }
        }

        private void ShowAnswers()
        {
            reshuffle(randAns);
            cmbAnswers.Items.Clear();//empty previous selection
            cmbAnswers.Items.AddRange(randAns); //update selected items to new random shuffle
            panelAnswers.Visible = true; //show the panel of elements

        }

        //timer works every interval and then stops and image is invisible
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            pictureBox1.Visible = false;
            //choose answers and make answers panel visible
            ShowAnswers();
        }

        //chooses new Image and restarts the timer
        private void btnNext_Click(object sender, EventArgs e)
        {
            pictureBox1.Visible = true;
            chooseImage();
            lblCorrect.Visible = false; //when panel will be visible the label will still be invisible
            panelAnswers.Visible = false;
            timer1.Start();
        }

        
        private void label1_Click(object sender, EventArgs e)
        {
            if (timer1.Enabled == true) lblHint.Text = pArrDesc[index];
            else lblHint.Text = "No hint";
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            lblHint.Text = "No hint";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            chooseImage(); //chooseing new Image when picturebox is still visible
         }

        //not a default event of picture box
        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            lblHint.Text = "Last hint  -  " + pArrDesc[index];
            lblHint.Visible = true;
        }

        
        private void cmbAnswers_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbAnswers.SelectedItem.ToString() == pArrDesc[index])
            {
                lblCorrect.Text = "CORRECT";
                //update timer one second less untill one second as minimal value
                if (interval>=2000) interval = interval-1000;
                timer1.Interval = interval;
            }
            else
                lblCorrect.Text = "INCORRECT";
            lblCorrect.Visible = true;
        }
    }
}
